%% ESTA MAL, CONSULTAR SI SIQUIERA ES POSIBLE UN PEINE CONTINUO

function h = peine(t, N)
  if nargin < 2, N=1; end;
end
