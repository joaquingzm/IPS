function h = cajon(t)
  h = 1.*(t>=-0.5 & t<=0.5);
end
