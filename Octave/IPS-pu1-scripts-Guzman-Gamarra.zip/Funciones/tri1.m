function h = tri1(t)
  % TRI senal triangular del EJ6 P1
  h = 2.*tri((1/2).*(t-1));
end
