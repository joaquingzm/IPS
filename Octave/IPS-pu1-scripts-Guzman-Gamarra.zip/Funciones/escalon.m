function h = escalon(t)
  h = 1.*(t>=0);
end
