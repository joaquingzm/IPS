Aclaraciones:
-Para poder ejecutar el menu interactivo se debe ejecutar el archivo main.m ubicado dentro de la carpeta /Laboratorio1. 
-Para la correcta ejecucion de main.m se debe ejecutar este desde un path que no contenga letras "ñ".
-La estructura de directorios deberia ser: 
/(ruta donde se almacenaron las carpetas adjuntas)
	/Funciones
	/Laboratorio1
		/Ejercicio1
		/Ejercicio2
		/GraficosEj01
		/GraficosEj02
		/IPS2025_PU1
		main.m
	README.txt
-Para el ejercicio 2 inciso 4 se sugiere hacer zoom en las posiciones de n que se detallan a continuacion para poder observar los ecos correspondientes: 
Canal + Filtro1 -> n=26460
Canal + Filtro2 -> n=35280 y n=44100
Canal + Filtro3 -> n=52920
